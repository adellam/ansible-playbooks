class GlobalRole < ActiveRecord::Base
  unloadable

  belongs_to :role
  belongs_to :principal, foreign_key: :user_id
  validates_uniqueness_of :user_id, :scope => :role_id

end
