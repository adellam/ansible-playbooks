## Usability

#### Plugin for Redmine


==========
[skin]: https://bitbucket.org/dkuk/redmine_alex_skin.git
[common_libs]: https://bitbucket.org/dkuk/a_common_libs
Attention! Plugin "Usability" requires plugin ["a_common_libs"][common_libs] and skin [Redmine Alex Skin][skin] to correct work.


=========

#### Installation

=========
[site]: http://rmplus.prp.ru/ru/redmine/plugins/usability

Look for information on our ["site"][site].

#### Supported Redmine, Ruby and Rails versions.

Plugin aims to support and is tested under the following Redmine implementations:
* Redmine 2.3.1
* Redmine 2.3.2
* Redmine 2.3.3

Plugin aims to support and is tested under the following Ruby implementations:
* Ruby 1.9.2
* Ruby 1.9.3
* Ruby 2.0.0

Plugin aims to support and is tested under the following Rails implementations:
* Rails 3.2.13

#### Copyright
Copyright (c) 2011-2013 Vladimir Pitin, Danil Kukhlevskiy.

Another plugins of our team you can see on site http://rmplus.pro
