module Usability
  module ActivitiesControllerPatch
    def self.included(base)
      base.send(:include, InstanceMethods)
      base.class_eval do
        alias_method_chain :index, :usability
      end
    end

    module InstanceMethods
      def index_with_usability
        if Journal.activity_provider_options['issues'].present? && Journal.activity_provider_options['issues'][:find_options].present?
          if Setting.plugin_usability['enable_full_activities_for_issues']
            Journal.activity_provider_options['issues'][:find_options][:conditions] = "#{Journal.table_name}.journalized_type = 'Issue'"
            Journal.event_options[:type] = Proc.new { |o| o.notes.blank? ? ((s = o.new_status).present? && s.is_closed? ? 'issue-closed' : 'issue-edit') : 'issue-note' }
          else
            Journal.activity_provider_options['issues'][:find_options][:conditions] = "#{Journal.table_name}.journalized_type = 'Issue' AND (#{JournalDetail.table_name}.prop_key = 'status_id' OR #{Journal.table_name}.notes <> '')"
            Journal.event_options[:type] = Proc.new { |o| (s = o.new_status) ? (s.is_closed? ? 'issue-closed' : 'issue-edit') : 'issue-note' }
          end
        end
        index_without_usability
      end
    end
  end
end