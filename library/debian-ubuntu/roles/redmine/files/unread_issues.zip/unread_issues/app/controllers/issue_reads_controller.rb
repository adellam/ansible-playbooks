class IssueReadsController < ApplicationController

  def count
    unless Redmine::Plugin.installed?(:ajax_counters)
      render nothing: true
    end

    num_issues = 0
    query_id = (Setting.plugin_unread_issues || {})[:assigned_issues].to_i
    if query_id != 0
      begin
        query = IssueQuery.find(query_id)
        query.group_by = ''
      rescue ActiveRecord::RecordNotFound
        ajax_counter_respond(num_issues)
        return
      end
    else
      ajax_counter_respond(num_issues)
      return
    end

    case params[:req]
      when 'assigned'
        num_issues = query.issues.count
      when 'unread'
        num_issues = query.issues(conditions: "#{IssueRead.table_name}.read_date is null").count
      when 'updated'
        num_issues = query.issues(conditions: "#{IssueRead.table_name}.read_date < #{Issue.table_name}.updated_on").count
    end
    # save counter to prevent extra ajax request

    ajax_counter_respond(num_issues)
  end

  def view_stats
    @issue = Issue.find(params[:id])
    @issue_reads = @issue.issue_reads
  end
end
