## Unread issues

#### Plugin for Redmine

The plugin implements a convenient functionality of monitoring changes in issues.

Read more on http://rmplus.pro/redmine/plugins/unread_issues

#### Copyright
Copyright (c) 2011-2013 Vladimir Pitin, Danil Kukhlevskiy.
[skin]: https://github.com/tdvsdv/redmine_alex_skin
For better appearance we recommend to use this plugin with Redmine skin of our team - [Redmine Alex Skin][skin].

Another plugins of our team you can see on site http://rmplus.pro

changelog:
  2015-01-29:
    * minor fixes
    * tested support Redmine 2.6
