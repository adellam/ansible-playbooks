# ShinyProxy Stock Trends

# shinyStockTrends
Shiny web app to produce ICES stock trend plots (.png) and tables (.csv)

## To run locally:

If you have R on your computer, you should be able to run the web app

```{r}
## if you don't have shiny loaded:
# install.packages("shiny")

library(shiny)
runGitHub("ices-tools-dev/shinyStockTrends", subdir = "/StockTrends")
```


This app should also work with [ShinyProxy](http://www.shinyproxy.io).


On my PC using PowerShell:
```
sc config docker binpath= "\"C:\Program Files\docker\dockerd.exe\" --run-service -H tcp://0.0.0.0:2375"
```
(note, this didn't work.(this blog)[http://blog.simontimms.com/2016/07/20/windows_docker_daemon/] to change the port) 


If you want to build a Docker image from the Dockerfile in this repository, navigate into the root directory
```
cd `D:\Profiles\Scott\My Documents\git\shinyproxyapps\stocktrends\`
```
 
and run:
```
docker build -t stocktrends .
```

Running the image for testing purposes outside ShinyProxy can be done using:
```
docker run -it -p 3838:3838 stocktrends
```

Navigate to [localhost:3838](http://localhost:3838/) and play around



To launch with ShinyProxy, change the working directory
``` 
cd D:\Profiles\Scott\My Documents\git\shinyproxy\target\
```

And run the image with ShinyProxy:
```
java -jar "shinyproxy-0.7.8.jar"
```

Navigate to [localhost:8080](http://localhost:8080/) and play around

