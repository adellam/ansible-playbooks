# Beuller Template

This is modified from a template to deploy your own Shiny apps on [ShinyProxy](http://www.shinyproxy.io).

Full explanation on the contents of this repository is offered at
http://www.shinyproxy.io/deploying-apps/

In command prompt used:
```
sc config docker binpath= "\"C:\Program Files\docker\dockerd.exe\" --run-service -H tcp://0.0.0.0:2375"
```
(note, this didn't work.(this blog)[http://blog.simontimms.com/2016/07/20/windows_docker_daemon/] to change the port) 

The purpose of this repository is to customize it for your needs, but if you want to build a Docker image from the Dockerfile in this repository, navigate into the root directory
```
cd `D:\Profiles\Scott\My Documents\git\shinyproxyapps\eueler\`
```
 
and run:
```
docker build -t euler .
```

Running the image for testing purposes outside ShinyProxy can be done using:
```
docker run -it -p 3838:3838 euler
```

Navigate to [localhost:3838](http://localhost:3838/) and play around




First change the working directory, then
``` 
cd D:\Profiles\Scott\My Documents\git\shinyproxy\target\
```

Running the image using ShinyProxy can be done using:
```
java -jar "shinyproxy-0.7.8.jar"
```

