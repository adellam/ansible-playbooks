# ShinyProxy DLM tools

# DLM tools
Shiny web app to use DLM tools


This app should also work with [ShinyProxy](http://www.shinyproxy.io).

On my PC using PowerShell:
```
sc config docker binpath= "\"C:\Program Files\docker\dockerd.exe\" --run-service -H tcp://0.0.0.0:2375"
```
(note, this didn't work.(this blog)[http://blog.simontimms.com/2016/07/20/windows_docker_daemon/] to change the port) 


If you want to build a Docker image from the Dockerfile in this repository, navigate into the root directory
```
cd `D:\Profiles\Scott\My Documents\git\shinyproxyapps\dlm\`
```
 
and run:
```
docker build -t dlm .
```

Running the image for testing purposes outside ShinyProxy can be done using:
```
docker run -it -p 3838:3838 dlm
```

Navigate to [localhost:3838](http://localhost:3838/) and play around



To launch with ShinyProxy, change the working directory
``` 
cd D:\Profiles\Scott\My Documents\git\shinyproxy\target\
```

And run the image with ShinyProxy, first go to the target root and modify the applications.yml file with the new app
Next, run
```
java -jar "shinyproxy-0.7.8.jar"
```

Navigate to [localhost:8080](http://localhost:8080/) and play around

